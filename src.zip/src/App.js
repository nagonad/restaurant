import Navbar from "./Navbar.js";

import React, { Component } from "react";
import { Container, Row, Col } from "reactstrap";
import CategoryList from "./CategoryList.js";
import Menu from "./Menu.js";
import MenuList from "./MenuList";

async function fetchProducts() {
  const response = await fetch("http://localhost:3000/products");
  const products1 = response.json().then((data) => {
    return data;
  });
  // console.log(products1);
}

export default class App extends Component {
  state = { products: [] };
  allProducts = [];

  getProducts = (categoryId) => {
    let updatedProducts = [];

    let url = "http://localhost:3000/products";
    if (categoryId) {
      url += "?categoryId=" + categoryId;
    }

    fetchProducts();

    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        // console.log("fetch data ," + data);
        this.setState({ products: data });
      });
  };
  async componentDidMount() {
    await this.getProducts();

    this.state.products &&
      console.log("componentdidmount" + this.state.products.length);
  }

  render() {
    return (
      <Container>
        <Navbar />
        <Row>
          <Col xs="3">
            <CategoryList />
          </Col>
          <Col xs="9">
            {/* <Menu /> */}
            <MenuList products={this.state.products} />
          </Col>
        </Row>
      </Container>
    );
  }
}
