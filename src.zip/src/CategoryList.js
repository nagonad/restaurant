import React, { Component } from "react";
import { ListGroup, ListGroupItem } from "reactstrap";

export default class CategoryList extends Component {
  render() {
    return (
      <div>
        CategoryList
        <ListGroup>
          <ListGroupItem>Drehspieß Spezilitäten</ListGroupItem>
          <ListGroupItem>Döner Rollen</ListGroupItem>
        </ListGroup>
      </div>
    );
  }
}
